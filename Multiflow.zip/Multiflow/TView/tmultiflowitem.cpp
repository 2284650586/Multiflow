#include "tmultiflowitem.h"

TMultiflowItem::TMultiflowItem()
{

}

void TMultiflowItem::setType(int type)
{
    m_type = type;
}
