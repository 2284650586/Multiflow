#include "ttabwidget.h"

TTabWidget::TTabWidget(QWidget *parent) : QTabWidget(parent)
{

}
