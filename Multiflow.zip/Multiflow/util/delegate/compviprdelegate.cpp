#include "compviprdelegate.h"

CompVIPRDelegate::CompVIPRDelegate(QObject *parent)
    : QItemDelegate{parent}
{

}
