#include "geometrydelegate.h"

GeometryDelegate::GeometryDelegate(QObject *parent)
    : QItemDelegate{parent}
{

}
