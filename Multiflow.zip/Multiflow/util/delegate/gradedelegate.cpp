#include "gradedelegate.h"

GradeDelegate::GradeDelegate(QObject *parent)
    : QItemDelegate{parent}
{

}
