#include "editabledelegate.h"

EditableDelegate::EditableDelegate(QObject *parent) : QItemDelegate(parent) {}
