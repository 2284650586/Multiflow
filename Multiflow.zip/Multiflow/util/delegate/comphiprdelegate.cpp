#include "comphiprdelegate.h"

CompHIPRDelegate::CompHIPRDelegate(QObject *parent)
    : QItemDelegate{parent}
{

}
