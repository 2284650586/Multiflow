#include "readonlydelegate.h"

ReadOnlyDelegate::ReadOnlyDelegate(QObject *parent)
    : QItemDelegate{parent}
{

}
