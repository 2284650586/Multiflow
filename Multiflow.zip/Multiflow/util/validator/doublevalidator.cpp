#include "doublevalidator.h"

DoubleValidator::DoubleValidator(QObject *parent)
    : QValidator{parent}
{

}
